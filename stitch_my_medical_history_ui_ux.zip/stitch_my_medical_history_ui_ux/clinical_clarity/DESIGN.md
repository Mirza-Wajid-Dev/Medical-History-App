---
name: Clinical Clarity
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#414754'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#727785'
  outline-variant: '#c1c6d6'
  surface-tint: '#005bc0'
  primary: '#005abd'
  on-primary: '#ffffff'
  primary-container: '#1972e6'
  on-primary-container: '#fffeff'
  inverse-primary: '#adc7ff'
  secondary: '#006591'
  on-secondary: '#ffffff'
  secondary-container: '#39b8fd'
  on-secondary-container: '#004666'
  tertiary: '#4749d5'
  on-tertiary: '#ffffff'
  tertiary-container: '#6164ef'
  on-tertiary-container: '#fffdff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc7ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004493'
  secondary-fixed: '#c9e6ff'
  secondary-fixed-dim: '#89ceff'
  on-secondary-fixed: '#001e2f'
  on-secondary-fixed-variant: '#004c6e'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-sm: 0.75rem
  gutter-lg: 1.5rem
  margin: 1.25rem
  margin-sm: 1rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

This design system establishes an empathetic, calm, and uncompromisingly credible mobile sanctuary for personal health data. It balances the uncompromising precision of clinical informatics with the warm reassurance of a bespoke concierge wellness companion. 

The aesthetic is Modern Clinical-Luxe: crisp architectural structuring softened by deep-radius cards, tactile pills, and micro-diffused ambient glows. Surfaces remain airy and uncluttered, intentionally minimizing cognitive burden during high-stress medical encounters, hospital visits, or emergency consultations. Layouts prioritize rapid information retrieval, visual scannability, and high-legibility touch states that feel solid and native on high-density mobile screens.

## Colors

The palette leverages a clinically reassuring blue anchor supported by vibrant diagnostic accents, engineered against an immaculate slate-neutral foundation to avoid sterile starkness.

- **Brand Cores**:
  - Primary (`#1972E6`): Medical Trust Blue; provides unambiguous authority for primary actions, navigation active states, and critical system highlights.
  - Secondary (`#0EA5E9`): Oxygen Cyan/Teal; conveys vitality, used for secondary metrics, timeline connectors, and analytical chart highlights.
  - Tertiary (`#6366F1`): Prescription Indigo; reserved for pharmacy schedules, medication orders, and laboratory references.

- **Semantic Safeguards**:
  - Success (`#10B981`): Emerald; indicates normal lab ranges, resolved conditions, and completed inoculations.
  - Warning (`#F59E0B`): Amber; signals pending doctor reviews, borderline readings, and upcoming refills.
  - Critical (`#EF4444`): Coral Crimson; designates severe allergies, emergency contacts, contraindications, and out-of-range critical alerts.

- **Surfaces & Tonal Neutrals**:
  - App Canvas Base: `#F8FAFC` (Slate 50)
  - Surface Card Elevated: `#FFFFFF`
  - Subtle Inset/Muted Container: `#F1F5F9` (Slate 100)
  - Hairline Separators/Borders: `#E2E8F0` (Slate 200)
  - Secondary Text/Glyphs: `#64748B` (Slate 500)
  - High-Contrast Primary Text: `#0F172A` (Slate 900)

## Typography

The typographic hierarchy pairs the open geometry and humanized terminals of **Plus Jakarta Sans** for headlines with the hyper-legible, utilitarian neutrality of **Inter** for dense data readouts, dosage strings, and body notes.

Numerical data within clinical ranges, medication dosages (e.g., `500 mg`, `120/80 mmHg`), and timestamps should enforce tabular lining figures (`font-variant-numeric: tabular-nums`) to prevent vertical shifting during live biometric monitoring. Section titles retain authoritative weight without imposing overwhelming visual bulk. All microcopy, badge labels, and metadata adhere to strict contrast standards to ensure effortless reading in bright daylight or clinical exam rooms.

## Layout & Spacing

The layout model is optimized around mobile ergonomics, using a fluid single-column rail on phone viewports that expands to a 4-column structured grid on small tablets and a responsive 8-to-12-column split-pane master-detail view on larger displays.

- **Mobile Viewports (<600px)**: Default edge gutter of `1.25rem` (`margin`), leaving adequate thumbs-reach breathing room. Internal cards use `space-md` (`1rem`) to `space-lg` (`1.5rem`) inner padding.
- **Tablet & Split Panes (600px - 1024px)**: Outer margin expands to `margin-lg` (`2rem`). The interface bifurcates into a master list (e.g., medical categories, timeline) and an expansive inspection panel.
- **Vertical Rhythm**: Built upon a strict 4pt/8pt baseline grid. Stacked clinical events adhere to `space-md` gaps; cohesive related attributes (such as prescribing physician directly beneath a drug name) clamp tight with `space-xs` or `space-sm`.

## Elevation & Depth

Visual hierarchy uses a hybrid strategy of tonal separation, delicate ambient blue-grey shadows, and crisp surface keylines.

- **Level 0 (Canvas Base)**: `#F8FAFC`. Completely unshadowed, flat backdrop providing subtle tint against pure white cards.
- **Level 1 (Clinical Cards & Tiles)**: Background `#FFFFFF`, encased in a hairline border `1px solid #E2E8F0`. Layered with an ambient, diffused shadow: `0 2px 8px -2px rgba(15, 23, 42, 0.04), 0 1px 3px -1px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Active Cards & Floating Menus)**: `0 8px 24px -4px rgba(15, 23, 42, 0.08), 0 4px 8px -2px rgba(15, 23, 42, 0.03)`, border `1px solid #CBD5E1`. Used for dragged widgets, quick-filter sheets, and active date pickers.
- **Level 3 (Emergency Modals & Bottom Action Drawers)**: `0 20px 32px -8px rgba(15, 23, 42, 0.14)`, matched with a backdrop blur overlay (`rgba(15, 23, 42, 0.40)` with `blur(8px)`).
- **Interactive Depths**: Interactive surfaces do not jump abruptly in elevation; instead, touch-down triggers a subtle inner compression (scale 0.985) with an augmented border stroke tint (`#1972E6` at 30% alpha).

## Shapes

The design system employs a soft, protective geometry that mitigates medical anxiety. 

Cards, record containers, and input groups utilize a prominent `1rem` (16px, `rounded-lg`) to `1.5rem` (24px, `rounded-xl`) outer radius. Small interactive tags, status indicators, and pill buttons diverge intentionally into full pill forms (`rounded-full` / 9999px) to signal tap affordance and quick visual categorical scanning. Icon wrappers within cards use continuous squircles or `rounded-xl` to maintain geometric harmony with surrounding containers.

## Components

- **Buttons**:
  - *Primary*: Height 52px (optimized for tactile thumb hitboxes). Fill `#1972E6`, text `#FFFFFF`, radius `rounded-xl`. Elevation Level 1 with subtle blue glow on hover/active. Disabled state shifts to `#E2E8F0` fill with `#94A3B8` label.
  - *Secondary / Outline*: Height 52px. Transparent fill, `1.5px solid #E2E8F0`, text `#0F172A`. In active state, border transitions to `#1972E6` with a `#F1F5F9` wash.
  - *Floating Emergency Action*: Pill-shaped floating control anchored bottom-right or persistent bottom bar, combining `#EF4444` background with clear white iconography.

- **Status Badges & Chips**:
  - Full pill radius (`9999px`). 
  - *Normal/Success*: Background `rgba(16, 185, 129, 0.12)`, text `#047857`, 1px border `rgba(16, 185, 129, 0.20)`.
  - *Refill/Warning*: Background `rgba(245, 158, 11, 0.12)`, text `#B45309`, 1px border `rgba(245, 158, 11, 0.20)`.
  - *Critical/Allergy*: Background `rgba(239, 68, 68, 0.12)`, text `#B91C1C`, 1px border `rgba(239, 68, 68, 0.20)`.
  - *Filter Chips*: Inactive in `#F1F5F9` with `#475569` text; selected state in `#1972E6` with pure white text.

- **Cards & Health Record Tiles**:
  - Background `#FFFFFF`, radius 20px, stroke `1px solid #E2E8F0`. 
  - Header displays record category icon inside a soft 40x40px tinted rounded square, juxtaposed with standard trailing status pills. Body content uses clean two-tier metadata layout (label in `body-sm` Slate 500, value in `label-lg` Slate 900).

- **Input Fields & Search**:
  - Height 52px. Background `#F8FAFC`, transitioning to `#FFFFFF` upon focus. Border `1.5px solid #E2E8F0`, shifting to `2px solid #1972E6` when focused, accompanied by a soft 3px `#1972E6` focus ring at 15% opacity.
  - Floating label pattern ensuring clinical values, units, and placeholder helpers remain visible simultaneously.

- **Checkboxes & Radios**:
  - Sized at 22x22px with an expanded minimum 48x48px invisible touch target. Checkboxes use an 8px corner radius; radio targets use true concentric rings. Selected states render `#1972E6` with high-contrast white vector checks.

- **Timeline & Vitals Metric Cards**:
  - Dedicated chronological node elements with vertical rail connections in `#CBD5E1`.
  - Vital metrics feature bold numerical readouts (`display-lg`), inline sparkline indicators, and explicit reference interval tags (e.g., "Normal: 70–99 mg/dL").